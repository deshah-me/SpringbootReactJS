import React from 'react';
import {Form,Button} from "reactstrap";

const Home = () =>{
    return(
    <div className='center'>
      <Form>
        <h1>Hello, world!</h1>
        <p className='center'>
          This is a simple hero unit, a simple jumbotron-style component for calling
          extra attention to featured content or information.
        </p>
        <p>
          <Button bsStyle="primary">Learn more</Button>
        </p>
      </Form>
    </div>
    )
}

export default Home