import React from "react";
import { Button, Container, Form,FormGroup, Input } from "reactstrap";

const Addcourse = ()=>{
return(
    <div>
        <h3 className="text-center"><b>Fill Course Deatils</b></h3>
        <Form>
            <FormGroup>
                <label for="userId">Course Id</label>
                <Input type="text" placeholder="Enter here" name="title" id="title"/>      
            </FormGroup>

            <FormGroup>
                <label for="description">Course Name</label>
                <Input type="text" placeholder="Enter Name" name="name" id="name"/>    
            </FormGroup>

            <FormGroup>
                <label for="description">Course Description</label>
                <Input type="textarea" placeholder="Enter description" name="description" id="description"/>    
            </FormGroup>

            <Container className="text-center">
                <Button color="success">Add Course</Button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Button color="warning">Clear</Button>
            </Container>
        </Form>
    </div>
)

}
export default Addcourse;