import React, { useState } from "react";
import Course from "./Course";
const Allcourse =()=>{

    const [courses,setCourses]=useState([
        {title:"Java",description:"This is our Java Course for beginners"},
        {title:"Angular",description:"This is our Angular Course for beginners"},
        {title:"React",description:"This is our React Course for beginners"},
        {title:"Python",description:"This is our Python Course for beginners"},
    ])

    return(
        <div>
            <h1>All Courses</h1>
            <p>List of courses are as follows:</p>
        { 
        courses.length > 0 ? courses.map((item)=><Course course={item}/>) : "No Course"}
        </div>
    )

}
export default Allcourse;